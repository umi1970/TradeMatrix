# Branding and Design

Color Palette → Matrix Black (#0C0C0C), Signal Blue (#0070F3), Logic Gray (#E0E0E0), Profit Green (#00D084), Risk Red (#FF3B30)  

Charts → Dark Mode Layout, blauer Highlight bei Signalen, grüne TP-Linien, rote SL-Linien.  
Reports → schwarzer Hintergrund, weißer Text, Signalfarben für KPIs.
