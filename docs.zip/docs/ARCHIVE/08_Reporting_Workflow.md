# Reporting Workflow

- Daily Briefing → DOCX + JSON  
- Weekly Report → DOCX + Charts  
- Upload nach Google Drive und GitHub  
- Farbcode nach Matrix Branding
