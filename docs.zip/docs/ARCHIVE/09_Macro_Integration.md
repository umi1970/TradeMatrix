# Macro Integration

- CPI, FOMC, NFP, US Shutdown Events werden automatisch über TradingEconomics-API geladen.  
- NewsEventReaction.yaml bewertet Volatilitäts-Impact auf DAX, Dow, NASDAQ, EUR/USD.  
- Scheduler über Make.com (14:25 – 14:35 Scan).
