# Trade Flows (YAML)

- MorningPlanner_v3.yaml  
- NewsEventReaction.yaml  
- USOpenPlanner.yaml  
- EndOfMonthFlow.yaml  

Jeder Flow hat :
1. Input (Data + Indicators)  
2. Validation (TradeValidationEngine)  
3. Decision (TradeDecisionEngine)  
4. Journal / Report Output
