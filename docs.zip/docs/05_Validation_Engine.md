# Trade Validation Engine

## Metrics Weighting
| Metric | Weight |
|--------|---------|
| EMA Alignment | 0.25 |
| Pivot Confluence | 0.20 |
| Volume Confirmation | 0.20 |
| Candle Structure | 0.20 |
| Context Flow | 0.15 |

Confidence Score > 0.8 = High-Probability Trade.  
MR-04 & MR-06 überschreiben Pullback-Setups (MR-02).
