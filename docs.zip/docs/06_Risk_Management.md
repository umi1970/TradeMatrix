# Risk Management

- Max 1 % Risk pro Trade  
- Break Even bei +0,5 % Profit  
- 3 Verlusttrades = Pause  
- Immer SL + TP gesetzt  
- Positionsgröße = Depot × 0,01 / (Entry-SL)
